from setuptools import setup, find_packages

setup(
    name="grammar-feedback-agent",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "openai>=1.55.0",
        "python-dotenv==1.0.1",
    ],
    author="Praveen Kumar",
    author_email="your.email@organization.com",
    description="A package for grammar analysis using Azure OpenAI.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/grammar-feedback-agent",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
)